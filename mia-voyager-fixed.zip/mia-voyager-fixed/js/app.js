/**
 * Mia Voyager - Main Application Entry Point
 * Initialisiert alle Module und startet die App
 */

async function initApp() {
  const progressFill = document.getElementById('progressFill');
  const progressPercent = document.getElementById('progressPercent');
  const loadingText = document.querySelector('.loader-text');

  function updateProgress(percent, text) {
    progressFill.style.width = percent + '%';
    progressPercent.textContent = percent + '%';
    if (text) loadingText.textContent = text;
  }

  try {
    // Phase 1: Storage initialisieren
    updateProgress(10, 'Initialisiere Speicher...');
    await storage.init();
    console.log('✓ Storage initialisiert');

    // Phase 2: State Manager initialisieren
    updateProgress(30, 'Lade Mias Zustand...');
    await stateManager.init();
    console.log('✓ State Manager initialisiert');

    // Phase 3: Memory Engine initialisieren
    updateProgress(50, 'Lade Erinnerungen...');
    // Memory Engine hat keine async init, wird aber vorbereitet
    console.log('✓ Memory Engine bereit');

    // Phase 4: LLM Client initialisieren
    updateProgress(70, 'Verbinde mit KI...');
    await localLLMClient.init();
    console.log('✓ LLM Client initialisiert');

    // Phase 5: Dialog Generator initialisieren
    updateProgress(85, 'Bereite Dialog-System vor...');
    await dialogGenerator.init();
    console.log('✓ Dialog Generator initialisiert');

    // Phase 6: UI Controller initialisieren
    updateProgress(95, 'Starte Benutzeroberfläche...');
    uiController.init();
    console.log('✓ UI Controller initialisiert');

    // Fertig!
    updateProgress(100, 'Mia ist bereit!');

    // Kurze Pause für visuelle Bestätigung
    await new Promise(resolve => setTimeout(resolve, 500));

    // Wechsel zur Hauptansicht
    document.getElementById('loadingScreen').style.display = 'none';
    document.getElementById('app').style.display = 'flex';

    console.log('🚀 Mia Voyager erfolgreich gestartet!');

    // Initial UI Update
    uiController.updateUI(stateManager.getState());

  } catch (error) {
    console.error('❌ Initialisierungsfehler:', error);
    loadingText.textContent = 'Fehler beim Starten!';
    loadingText.style.color = '#ef4444';
    
    // Zeige detaillierte Fehlermeldung
    const errorDiv = document.createElement('div');
    errorDiv.style.cssText = 'color: #ef4444; margin-top: 20px; font-size: 12px; max-width: 400px; text-align: left;';
    errorDiv.innerHTML = `
      <strong>Fehlerdetails:</strong><br>
      ${error.message}<br><br>
      <small>Bitte überprüfe die Konsole (F12) für weitere Details.</small>
    `;
    document.querySelector('.loader-content').appendChild(errorDiv);

    // Retry Button
    const retryBtn = document.createElement('button');
    retryBtn.textContent = 'Neu versuchen';
    retryBtn.style.cssText = 'margin-top: 20px; padding: 10px 20px; background: #60a5fa; color: white; border: none; border-radius: 6px; cursor: pointer;';
    retryBtn.onclick = () => location.reload();
    document.querySelector('.loader-content').appendChild(retryBtn);
  }
}

// App-Lifecycle-Events
window.addEventListener('beforeunload', async (e) => {
  // Speichere den aktuellen Zustand vor dem Schließen
  try {
    await stateManager.saveState();
    console.log('✓ Zustand vor Schließen gespeichert');
  } catch (error) {
    console.error('Fehler beim Speichern vor Schließen:', error);
  }
});

// Starte die App, sobald DOM geladen ist
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

// Debug-Hilfe (nur in Entwicklung)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
  window.debugMia = {
    state: () => stateManager.getState(),
    memories: async () => await memoryEngine.getRecentMemories(null, 50),
    resetNeeds: () => {
      stateManager.state.needs = {
        hunger: 50,
        energy: 75,
        attachment: 90,
        security: 85,
        stimulation: 40,
        hygiene: 80,
      };
      stateManager.saveState();
    },
    addDay: async (days = 1) => await stateManager.advanceDay(days),
  };
  console.log('🐛 Debug-Modus aktiv. Nutze window.debugMia für Entwickler-Tools');
}
