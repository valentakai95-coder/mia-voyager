/**
 * Local LLM Client - Optimized for Thinking Models
 * Verbindung zu lokalen GGUF-Modellen über Ollama oder llama.cpp
 */

class LocalLLMClient {
  constructor() {
    this.apiUrl = 'http://localhost:11434'; // Default: Ollama
    this.model = 'mia-thinking'; // Dein importiertes Modell
    this.backendType = 'ollama'; // 'ollama' oder 'llamacpp'
  }

  async init() {
    const savedUrl = await storage.loadSetting('llm_api_url');
    const savedModel = await storage.loadSetting('llm_model');
    const savedBackend = await storage.loadSetting('llm_backend');
    
    if (savedUrl) this.apiUrl = savedUrl;
    if (savedModel) this.model = savedModel;
    if (savedBackend) this.backendType = savedBackend;

    console.log(`🔌 Verbinde mit ${this.backendType} auf ${this.apiUrl}...`);
    await this.testConnection();
  }

  async setApiUrl(url) {
    this.apiUrl = url.replace(/\/$/, '');
    await storage.saveSetting('llm_api_url', this.apiUrl);
    
    this.backendType = this.detectBackendType(url);
    await storage.saveSetting('llm_backend', this.backendType);
  }

  async setModel(model) {
    this.model = model;
    await storage.saveSetting('llm_model', model);
  }

  detectBackendType(url) {
    if (url.includes('11434')) return 'ollama';
    if (url.includes('8080')) return 'llamacpp';
    return 'ollama';
  }

  async testConnection() {
    try {
      if (this.backendType === 'ollama') {
        const response = await fetch(`${this.apiUrl}/api/tags`, {
          method: 'GET',
        });
        
        if (response.ok) {
          const data = await response.json();
          console.log('✅ Ollama verbunden. Verfügbare Modelle:', 
            data.models?.map(m => m.name).join(', ') || 'Keine');
          return true;
        }
      } else if (this.backendType === 'llamacpp') {
        const response = await fetch(`${this.apiUrl}/health`, {
          method: 'GET',
        });
        
        if (response.ok) {
          console.log('✅ llama.cpp Server verbunden');
          return true;
        }
      }
    } catch (error) {
      console.warn('⚠️ Keine Verbindung zum LLM-Server:', error.message);
      console.log('\n📖 Setup-Hilfe siehe README.md');
      return false;
    }
  }

  async chat(messages, options = {}) {
    if (this.backendType === 'ollama') {
      return await this.chatOllama(messages, options);
    } else if (this.backendType === 'llamacpp') {
      return await this.chatLlamaCpp(messages, options);
    } else {
      throw new Error('Unbekannter Backend-Typ');
    }
  }

  async chatOllama(messages, options = {}) {
    try {
      const requestBody = {
        model: this.model,
        messages: messages,
        stream: false,
        options: {
          // Optimiert für "Thinking"-Modelle
          temperature: options.temperature || 0.8,
          num_predict: options.max_tokens || 600, // Mehr für detaillierte Antworten
          top_p: options.top_p || 0.9,
          top_k: options.top_k || 40,
          repeat_penalty: 1.1, // Verhindert Wiederholungen
          presence_penalty: 0.6, // Mehr Varianz
          frequency_penalty: 0.3, // Weniger monoton
        }
      };

      const response = await fetch(`${this.apiUrl}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Ollama API Error (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      return data.message?.content || '';
      
    } catch (error) {
      console.error('Ollama Error:', error);
      throw new Error(`Ollama Fehler: ${error.message}\n\nStelle sicher, dass Ollama läuft: "ollama serve"`);
    }
  }

  async chatLlamaCpp(messages, options = {}) {
    try {
      const prompt = this.convertMessagesToPrompt(messages);

      const requestBody = {
        prompt: prompt,
        temperature: options.temperature || 0.8,
        n_predict: options.max_tokens || 600,
        top_p: options.top_p || 0.9,
        top_k: options.top_k || 40,
        repeat_penalty: 1.1,
        presence_penalty: 0.6,
        frequency_penalty: 0.3,
        stop: ["<|eot_id|>", "<|end_header_id|>", "User:", "Assistant:"],
      };

      const response = await fetch(`${this.apiUrl}/completion`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`llama.cpp API Error (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      return data.content?.trim() || '';
      
    } catch (error) {
      console.error('llama.cpp Error:', error);
      throw new Error(`llama.cpp Fehler: ${error.message}`);
    }
  }

  convertMessagesToPrompt(messages) {
    // Llama 3.3 Format
    let prompt = '';
    
    for (const msg of messages) {
      if (msg.role === 'system') {
        prompt += `<|start_header_id|>system<|end_header_id|>\n\n${msg.content}<|eot_id|>`;
      } else if (msg.role === 'user') {
        prompt += `<|start_header_id|>user<|end_header_id|>\n\n${msg.content}<|eot_id|>`;
      } else if (msg.role === 'assistant') {
        prompt += `<|start_header_id|>assistant<|end_header_id|>\n\n${msg.content}<|eot_id|>`;
      }
    }
    
    prompt += '<|start_header_id|>assistant<|end_header_id|>\n\n';
    return prompt;
  }

  async generateResponse(systemPrompt, userMessage, context = '') {
    const messages = [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: `[KONTEXT]\n${context}\n\n[USER]\n${userMessage}`,
      },
    ];

    return await this.chat(messages, {
      temperature: 0.85, // Etwas höher für kreativere kindliche Antworten
      max_tokens: 600,
      top_p: 0.9,
      top_k: 40,
    });
  }

  async listModels() {
    if (this.backendType !== 'ollama') {
      console.log('Modell-Liste nur für Ollama verfügbar');
      return [];
    }

    try {
      const response = await fetch(`${this.apiUrl}/api/tags`);
      if (!response.ok) return [];
      
      const data = await response.json();
      return data.models || [];
    } catch (error) {
      console.error('Fehler beim Laden der Modell-Liste:', error);
      return [];
    }
  }

  async pullModel(modelName) {
    if (this.backendType !== 'ollama') {
      throw new Error('Modell-Download nur für Ollama verfügbar');
    }

    console.log(`📥 Lade Modell: ${modelName}...`);
    
    try {
      const response = await fetch(`${this.apiUrl}/api/pull`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: modelName }),
      });

      if (!response.ok) {
        throw new Error('Fehler beim Laden des Modells');
      }

      console.log(`✅ Modell ${modelName} erfolgreich geladen`);
      return true;
    } catch (error) {
      console.error('Fehler beim Laden des Modells:', error);
      throw error;
    }
  }
}

const localLLMClient = new LocalLLMClient();
