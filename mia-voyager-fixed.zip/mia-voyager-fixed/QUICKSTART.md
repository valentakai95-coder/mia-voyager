# 🚀 Quick Start - Mia Voyager

## Schnellstart in 3 Schritten

### 1️⃣ Ollama installieren und starten

**Windows/Mac/Linux:**
```bash
# Download: https://ollama.ai/download

# Nach Installation, Terminal öffnen und starten:
ollama serve
```

**Lade ein Modell (in neuem Terminal):**
```bash
ollama pull llama3.2
```

### 2️⃣ Mia öffnen

- Öffne `index.html` in deinem Browser
- ODER starte einen lokalen Server:
  ```bash
  python -m http.server 8000
  # Dann öffne: http://localhost:8000
  ```

### 3️⃣ Konfigurieren

1. Klicke auf **⚙️ Einstellungen**
2. Server URL: `http://localhost:11434`
3. Modell: `llama3.2`
4. Klicke **"KI-Einstellungen speichern"**
5. Fertig! Sag Mia Hallo! 👋

---

## ⚡ Testen ob Ollama läuft

```bash
# Terminal:
curl http://localhost:11434/api/tags

# Sollte eine Liste von Modellen zeigen
```

## 🐛 Probleme?

**"Keine Verbindung zum LLM-Server"**
- Ist Ollama gestartet? → `ollama serve`
- Läuft auf Port 11434? → Prüfe mit curl

**"Modell nicht gefunden"**
- Hast du das Modell geladen? → `ollama pull llama3.2`
- Liste Modelle: → `ollama list`

**"Zu langsam"**
- Verwende kleineres Modell: `ollama pull llama3.2:1b`

---

## 📚 Weitere Infos

Siehe **README.md** für:
- Detaillierte Anleitung
- Modell-Empfehlungen
- Troubleshooting
- Technische Details

**Viel Spaß mit Mia! 👧✨**
