# 👧 Mia – AUM-Voyager

Eine KI-gesteuerte Simulation eines 3-jährigen Mädchens namens Mia, die auf dem Raumschiff AUM-Voyager aufwächst. Die App nutzt **lokale GGUF-Modelle** für authentische, entwicklungsgerechte Interaktionen.

## 🌟 Features

- **Psychologisch authentisch**: Entwicklungsstufen, Bedürfnisse, Emotionen
- **Persistentes Gedächtnis**: IndexedDB speichert alle Interaktionen
- **Zeitbasierte Entwicklung**: Mia altert und entwickelt sich über Tage/Monate
- **Lokale KI**: Nutzt GGUF-Modelle über Ollama oder llama.cpp
- **Privacy-First**: Alle Daten bleiben lokal auf deinem Computer

## 🚀 Setup-Anleitung

### Schritt 1: Lokale KI installieren

#### Option A: Ollama (Empfohlen - Einfachste Methode)

1. **Installiere Ollama:**
   - Windows/Mac/Linux: https://ollama.ai/download

2. **Starte Ollama:**
   ```bash
   ollama serve
   ```

3. **Lade ein Modell:**
   ```bash
   # Empfohlen für Mia (gute Balance):
   ollama pull llama3.2
   
   # Alternativen:
   ollama pull llama3.2:1b    # Schneller, weniger RAM
   ollama pull mistral        # Größer, bessere Qualität
   ollama pull phi3           # Microsoft, kompakt
   ```

4. **Teste die Verbindung:**
   ```bash
   curl http://localhost:11434/api/tags
   ```

#### Option B: llama.cpp (Für Fortgeschrittene)

1. **Installiere llama.cpp:**
   ```bash
   git clone https://github.com/ggerganov/llama.cpp
   cd llama.cpp
   make
   ```

2. **Lade ein GGUF-Modell:**
   - Hugging Face: https://huggingface.co/models?search=gguf

3. **Starte den Server:**
   ```bash
   ./server -m /path/to/model.gguf --host 0.0.0.0 --port 8080
   ```

### Schritt 2: Mia-Voyager starten

1. **Dateien vorbereiten:**
   ```
   mia-voyager/
   ├── index.html
   ├── css/
   │   └── style.css
   └── js/
       ├── app.js
       ├── ui.js
       ├── llm.js
       ├── dialog.js
       ├── state.js
       ├── memory.js
       └── storage.js
   ```

2. **Öffne index.html** in deinem Browser
   - Einfach doppelklicken oder
   - Mit lokalem Server (empfohlen):
     ```bash
     # Python 3
     python -m http.server 8000
     
     # Node.js
     npx http-server
     ```

3. **Konfiguriere die KI:**
   - Klicke auf ⚙️ (Einstellungen)
   - Setze Server URL:
     - Ollama: `http://localhost:11434`
     - llama.cpp: `http://localhost:8080`
   - Wähle ein Modell (z.B. `llama3.2`)
   - Klicke "KI-Einstellungen speichern"

4. **Starte die Konversation!**
   - Gib eine Nachricht ein
   - Mia antwortet entwicklungsgerecht als 3-Jährige

## 📖 Nutzung

### Erste Schritte
- **Begrüßung:** "Hallo Mia!"
- **Spielen:** "Lass uns spielen!"
- **Fragen:** "Wo ist Mama?"
- **Bedürfnisse:** Achte auf die Balken rechts (Hunger, Energie, etc.)

### Bedürfnisse verstehen
- **Hunger < 20:** Mia wird quengelig
- **Energie < 20:** Mia ist übermüdet
- **Attachment < 30:** Mia will Nähe zu Papa
- **Stimulation < 30:** Mia ist gelangweilt

### Zeit vorstellen
- Einstellungen → Zeit-Kontrolle → Tage vorstellen
- Mia altert und entwickelt sich (180 Tage = 1 Jahr)

### Daten verwalten
- **Exportieren:** Sichere Mias Zustand & Erinnerungen
- **Importieren:** Lade einen gespeicherten Zustand
- **Zurücksetzen:** Starte von vorne (WARNUNG: Löscht alles!)

## 🎨 System-Prompt anpassen

Der System-Prompt definiert Mias Persönlichkeit und Verhalten. Du kannst ihn in den Einstellungen anpassen:

```
Du bist Mia, ein 3 Jahre altes Mädchen...

SPRACHNIVEAU (3 Jahre):
- Einfache Sätze (3-5 Worte)
- Grammatikfehler sind normal
- Warum-Fragen SEHR häufig
...
```

## 🔧 Technische Details

### Architektur
- **Frontend:** Vanilla JavaScript (kein Framework)
- **Speicher:** IndexedDB (persistent, offline-fähig)
- **KI-Backend:** Ollama/llama.cpp (lokal)
- **Modelle:** GGUF-Format (quantisiert)

### Dateien & Verantwortlichkeiten
- `app.js` - Hauptinitialisierung
- `ui.js` - UI-Controller & Event-Handling
- `llm.js` - Lokale LLM-Kommunikation
- `dialog.js` - Antwort-Generierung
- `state.js` - Zustandsverwaltung (Alter, Bedürfnisse)
- `memory.js` - Erinnerungs-Engine
- `storage.js` - IndexedDB-Wrapper

### Empfohlene Modelle

| Modell | Größe | RAM | Qualität | Geschwindigkeit |
|--------|-------|-----|----------|-----------------|
| llama3.2:1b | 1.3 GB | 4 GB | ⭐⭐⭐ | ⚡⚡⚡⚡ |
| llama3.2:3b | 2 GB | 8 GB | ⭐⭐⭐⭐ | ⚡⚡⚡ |
| llama3.2 | 4.7 GB | 8 GB | ⭐⭐⭐⭐⭐ | ⚡⚡ |
| mistral | 4.1 GB | 8 GB | ⭐⭐⭐⭐⭐ | ⚡⚡ |

## 🐛 Troubleshooting

### "Keine Verbindung zum LLM-Server"
- Prüfe, ob Ollama läuft: `ollama serve`
- Teste URL: `curl http://localhost:11434/api/tags`
- Prüfe Firewall-Einstellungen

### "Modell nicht gefunden"
- Liste verfügbare Modelle: `ollama list`
- Lade Modell: `ollama pull llama3.2`

### "Antworten sind zu langsam"
- Verwende ein kleineres Modell (llama3.2:1b)
- Reduziere max_tokens in llm.js
- Nutze GPU-Beschleunigung (CUDA/Metal)

### "Browser-Konsole zeigt Fehler"
- Öffne Dev-Tools (F12)
- Prüfe Console-Tab für Details
- Prüfe Network-Tab für API-Fehler

## 🔐 Privacy & Sicherheit

- **Alle Daten bleiben lokal** - Nichts wird an externe Server gesendet
- **Kein Tracking** - Keine Analytics, keine Telemetrie
- **Open Source** - Du kannst den Code prüfen und anpassen
- **Offline-fähig** - Funktioniert ohne Internet (nach Setup)

## 📝 Lizenz

MIT License - Frei nutzbar für private und kommerzielle Zwecke

## 🤝 Credits

- **KI-Backend:** Ollama / llama.cpp
- **Konzept:** Entwicklungspsychologie + Science Fiction
- **Design:** Dunkles UI inspiriert von Raumschiff-Terminals

## 🚀 Nächste Schritte

- [ ] Voice-Integration (Text-to-Speech)
- [ ] Visuelle Emotionen (Avatare)
- [ ] Mehr NPCs (Lea, andere Crew-Mitglieder)
- [ ] Story-Events (automatische Ereignisse)
- [ ] Mobile App (Progressive Web App)

---

**Viel Spaß mit Mia! 👧✨**

Bei Fragen oder Problemen: Öffne ein Issue auf GitHub oder check die Konsole (F12) für Debug-Infos.
